# Graphics-OpenGLPipeline

bash run.sh

To rotate camera -> Left Click on background pixel (including the floor) and drag mouse <br />
To move camera along camera Z axis -> Left Click + Shift + Mouse Drag <br />
To rotate head, torso, base of SnowMan -> Click on base and drag the mouse <br />
To rotate torso and base of SnowMan -> Click on the torso and drag the mouse <br />
To rotate head of SnowMan -> Click on head and drag the mouse <br />

To move the Specular Spheres -> Click and Drag<br />
